# বাংলাদেশ ছাত্রলীগ পটুয়াখালী – অ্যাপ

## ১. Firebase সেটআপ (একবারই)
1. https://console.firebase.google.com এ নতুন প্রজেক্ট খুলুন।
2. Build > Firestore Database > Create database (Production mode)।
3. Rules ট্যাবে নিচের রুল বসিয়ে Publish করুন:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /members/{id} {
      allow read, create, update, delete: if true;
    }
  }
}
```
4. Project settings > General > "Add app" > Web (</>) চেপে একটি Web app নিবন্ধন করুন। সেখানে `apiKey` ও `projectId` পাবেন।
5. `lib/config.dart` ফাইলে `projectId` ও `apiKey` বসান।

## ২. GitHub এ APK বানানো
1. GitHub এ নতুন repository খুলুন এবং এই ফোল্ডারের সব ফাইল (`.github` ফোল্ডারসহ) আপলোড করুন।
2. Actions ট্যাবে "Build APK" নিজে থেকেই চলবে (না চললে Run workflow চাপুন)।
3. কাজ শেষ হলে ওই run এর নিচে Artifacts থেকে `BSL-Patuakhali-APK` ডাউনলোড করুন।
