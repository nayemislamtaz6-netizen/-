/// এই ফাইলের মানগুলো আপনার নিজের তথ্য দিয়ে বদলাতে হবে।
class Config {
  // Firebase Console > Project settings > General থেকে নিন
  static const String projectId = 'YOUR_FIREBASE_PROJECT_ID';
  static const String apiKey = 'YOUR_FIREBASE_WEB_API_KEY';

  // অ্যাডমিনের হোয়াটসঅ্যাপ নাম্বার
  static const String adminWhatsapp = '01771062549';

  // অ্যাডমিন পাসওয়ার্ড
  static const String adminPassword = '1971';

  static const String appName = 'বাংলাদেশ ছাত্রলীগ পটুয়াখালী';
}
