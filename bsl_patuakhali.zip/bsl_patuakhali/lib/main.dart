import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'config.dart';

// ───────────────────────── রং ─────────────────────────
class AppColors {
  static const green = Color(0xFF006A4E); // বাংলাদেশের সবুজ
  static const deepGreen = Color(0xFF003D2C);
  static const darkGreen = Color(0xFF07221A);
  static const red = Color(0xFFF42A41); // রক্তলাল
  static const deepRed = Color(0xFF8E1423);
  static const gold = Color(0xFFFFD166);
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const BslApp());
}

class BslApp extends StatelessWidget {
  const BslApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: Config.appName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.green,
          brightness: Brightness.dark,
          primary: AppColors.red,
          secondary: AppColors.green,
        ),
        scaffoldBackgroundColor: AppColors.darkGreen,
      ),
      home: const Gate(),
    );
  }
}

// ───────────────────────── ডাটা মডেল ─────────────────────────
class Member {
  final String name;
  final String phone;
  final String designation;
  Member({required this.name, required this.phone, this.designation = ''});
}

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
}

// ───────────────────────── Firestore REST API ─────────────────────────
class Api {
  static const String _base =
      'https://firestore.googleapis.com/v1/projects/${Config.projectId}/databases/(default)/documents';
  static const String _key = Config.apiKey;
  static const Duration _timeout = Duration(seconds: 20);

  static String normalizePhone(String input) {
    const bn = '০১২৩৪৫৬৭৮৯';
    final sb = StringBuffer();
    for (final ch in input.trim().split('')) {
      final i = bn.indexOf(ch);
      sb.write(i >= 0 ? '$i' : ch);
    }
    return sb.toString().replaceAll(RegExp(r'[^0-9]'), '');
  }

  static String hashPassword(String phone, String pass) =>
      sha256.convert(utf8.encode('$phone:$pass:bsl-patuakhali')).toString();

  static String _str(Map<String, dynamic>? fields, String key) {
    final v = fields?[key];
    if (v is Map && v['stringValue'] is String) return v['stringValue'] as String;
    return '';
  }

  static Future<List<Member>> listMembers() async {
    final out = <Member>[];
    String? token;
    do {
      var url = '$_base/members?key=$_key&pageSize=300'
          '&mask.fieldPaths=name&mask.fieldPaths=phone&mask.fieldPaths=designation';
      if (token != null) url += '&pageToken=$token';
      final res = await http.get(Uri.parse(url)).timeout(_timeout);
      if (res.statusCode != 200) {
        throw ApiException('তালিকা লোড করা যায়নি (কোড ${res.statusCode})');
      }
      final data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final docs = (data['documents'] as List?) ?? [];
      for (final d in docs) {
        final f = (d as Map<String, dynamic>)['fields'] as Map<String, dynamic>?;
        final phone = _str(f, 'phone');
        if (phone.isEmpty) continue;
        out.add(Member(
          name: _str(f, 'name'),
          phone: phone,
          designation: _str(f, 'designation'),
        ));
      }
      token = data['nextPageToken'] as String?;
    } while (token != null && token.isNotEmpty);
    return out;
  }

  static Future<Member> register(String name, String phone, String pass) async {
    final body = jsonEncode({
      'fields': {
        'name': {'stringValue': name},
        'phone': {'stringValue': phone},
        'passHash': {'stringValue': hashPassword(phone, pass)},
        'designation': {'stringValue': ''},
        'createdAt': {'timestampValue': DateTime.now().toUtc().toIso8601String()},
      }
    });
    final res = await http
        .post(
          Uri.parse('$_base/members?documentId=$phone&key=$_key'),
          headers: {'Content-Type': 'application/json'},
          body: body,
        )
        .timeout(_timeout);
    if (res.statusCode == 200) return Member(name: name, phone: phone);
    if (res.statusCode == 409) {
      throw ApiException('এই নাম্বার দিয়ে আগেই নিবন্ধন করা হয়েছে। "লগইন" করুন।');
    }
    throw ApiException('নিবন্ধন সম্পন্ন হয়নি (কোড ${res.statusCode})');
  }

  static Future<Member> login(String phone, String pass) async {
    final res =
        await http.get(Uri.parse('$_base/members/$phone?key=$_key')).timeout(_timeout);
    if (res.statusCode == 404) {
      throw ApiException('এই নাম্বারে কোনো সদস্য পাওয়া যায়নি।');
    }
    if (res.statusCode != 200) {
      throw ApiException('লগইন করা যায়নি (কোড ${res.statusCode})');
    }
    final data = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
    final f = data['fields'] as Map<String, dynamic>?;
    if (_str(f, 'passHash') != hashPassword(phone, pass)) {
      throw ApiException('পাসওয়ার্ড ভুল হয়েছে।');
    }
    return Member(
        name: _str(f, 'name'), phone: phone, designation: _str(f, 'designation'));
  }

  static Future<void> setDesignation(String phone, String designation) async {
    final res = await http
        .patch(
          Uri.parse('$_base/members/$phone?updateMask.fieldPaths=designation&key=$_key'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'fields': {
              'designation': {'stringValue': designation}
            }
          }),
        )
        .timeout(_timeout);
    if (res.statusCode != 200) {
      throw ApiException('পদবি সংরক্ষণ হয়নি (কোড ${res.statusCode})');
    }
  }

  static Future<void> deleteMember(String phone) async {
    final res =
        await http.delete(Uri.parse('$_base/members/$phone?key=$_key')).timeout(_timeout);
    if (res.statusCode != 200) {
      throw ApiException('মুছে ফেলা যায়নি (কোড ${res.statusCode})');
    }
  }
}

// ───────────────────────── ব্যাকগ্রাউন্ড (লাল-সবুজ) ─────────────────────────
class AppBackground extends StatelessWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [AppColors.deepGreen, AppColors.darkGreen, Color(0xFF2A0B10)],
          stops: [0.0, 0.55, 1.0],
        ),
      ),
      child: Stack(
        children: [
          // বাংলাদেশের পতাকার লাল বৃত্তের আভা
          Positioned(
            right: -90,
            bottom: -90,
            child: Container(
              width: 280,
              height: 280,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.red.withOpacity(0.18),
              ),
            ),
          ),
          Positioned(
            left: -70,
            top: 140,
            child: Container(
              width: 170,
              height: 170,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.green.withOpacity(0.25),
              ),
            ),
          ),
          child,
        ],
      ),
    );
  }
}

void showSnack(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));
}

Future<void> openWhatsapp() async {
  final uri = Uri.parse('https://wa.me/88${Config.adminWhatsapp}');
  await launchUrl(uri, mode: LaunchMode.externalApplication);
}

// ───────────────────────── গেট: নিবন্ধিত কিনা দেখে ─────────────────────────
class Gate extends StatefulWidget {
  const Gate({super.key});

  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  bool _loading = true;
  String? _phone;
  String? _name;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _phone = p.getString('phone');
      _name = p.getString('name');
      _loading = false;
    });
  }

  Future<void> _onRegistered(String name, String phone) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('phone', phone);
    await p.setString('name', name);
    if (!mounted) return;
    setState(() {
      _phone = phone;
      _name = name;
    });
  }

  Future<void> _logout() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('phone');
    await p.remove('name');
    if (!mounted) return;
    setState(() {
      _phone = null;
      _name = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        body: AppBackground(
          child: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipOval(child: Image.asset('assets/logo.png', width: 110, height: 110)),
                const SizedBox(height: 24),
                const CircularProgressIndicator(color: AppColors.red),
              ],
            ),
          ),
        ),
      );
    }
    if (_phone == null) {
      return RegisterScreen(onDone: _onRegistered);
    }
    return HomeScreen(myName: _name ?? '', myPhone: _phone!, onLogout: _logout);
  }
}

// ───────────────────────── সদস্য নিবন্ধন (প্রথম পেইজ) ─────────────────────────
class RegisterScreen extends StatefulWidget {
  final Future<void> Function(String name, String phone) onDone;
  const RegisterScreen({super.key, required this.onDone});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _pass = TextEditingController();
  bool _loginMode = false;
  bool _loading = false;
  bool _hide = true;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final name = _name.text.trim();
    final phone = Api.normalizePhone(_phone.text);
    final pass = _pass.text;

    String? err;
    if (!_loginMode && name.length < 2) {
      err = 'আপনার নাম লিখুন।';
    } else if (!RegExp(r'^01\d{9}$').hasMatch(phone)) {
      err = 'সঠিক ১১ ডিজিটের মোবাইল নাম্বার দিন (যেমন 01XXXXXXXXX)।';
    } else if (pass.length < 4) {
      err = 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।';
    }
    if (err != null) {
      setState(() => _error = err);
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final m = _loginMode
          ? await Api.login(phone, pass)
          : await Api.register(name, phone, pass);
      await widget.onDone(m.name, m.phone);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  InputDecoration _dec(String label, IconData icon, {Widget? suffix}) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, color: Colors.white70),
      suffixIcon: suffix,
      filled: true,
      fillColor: Colors.white.withOpacity(0.08),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: const BorderSide(color: AppColors.red, width: 1.6),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 440),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white,
                      ),
                      child: ClipOval(
                        child: Image.asset('assets/logo.png', width: 104, height: 104),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      Config.appName,
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'জয় বাংলা  ·  জয় বঙ্গবন্ধু',
                      style: TextStyle(color: AppColors.gold, fontSize: 14),
                    ),
                    const SizedBox(height: 28),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: Container(
                      color: Colors.black.withOpacity(0.28),
                      child: Column(children: [
                        Container(height: 4, color: AppColors.red),
                        Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            _loginMode ? 'সদস্য লগইন' : 'সদস্য নিবন্ধন',
                            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                          ),
                          const SizedBox(height: 16),
                          if (!_loginMode) ...[
                            TextField(
                              controller: _name,
                              textInputAction: TextInputAction.next,
                              decoration: _dec('নাম', Icons.person_outline),
                            ),
                            const SizedBox(height: 12),
                          ],
                          TextField(
                            controller: _phone,
                            keyboardType: TextInputType.phone,
                            textInputAction: TextInputAction.next,
                            decoration: _dec('মোবাইল নাম্বার', Icons.phone_outlined),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: _pass,
                            obscureText: _hide,
                            onSubmitted: (_) => _submit(),
                            decoration: _dec(
                              'পাসওয়ার্ড',
                              Icons.lock_outline,
                              suffix: IconButton(
                                icon: Icon(
                                  _hide ? Icons.visibility_off : Icons.visibility,
                                  color: Colors.white70,
                                ),
                                onPressed: () => setState(() => _hide = !_hide),
                              ),
                            ),
                          ),
                          if (_error != null) ...[
                            const SizedBox(height: 12),
                            Text(_error!, style: const TextStyle(color: Color(0xFFFF8A95))),
                          ],
                          const SizedBox(height: 20),
                          SizedBox(
                            height: 50,
                            child: FilledButton(
                              style: FilledButton.styleFrom(
                                backgroundColor: AppColors.red,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                ),
                              ),
                              onPressed: _loading ? null : _submit,
                              child: _loading
                                  ? const SizedBox(
                                      width: 22,
                                      height: 22,
                                      child: CircularProgressIndicator(
                                          strokeWidth: 2.5, color: Colors.white),
                                    )
                                  : Text(
                                      _loginMode ? 'লগইন করুন' : 'নিবন্ধন করুন',
                                      style: const TextStyle(
                                          fontSize: 17, fontWeight: FontWeight.w700),
                                    ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          TextButton(
                            onPressed: _loading
                                ? null
                                : () => setState(() {
                                      _loginMode = !_loginMode;
                                      _error = null;
                                    }),
                            child: Text(
                              _loginMode
                                  ? 'নতুন সদস্য? নিবন্ধন করুন'
                                  : 'আগেই নিবন্ধন করেছেন? লগইন করুন',
                              style: const TextStyle(color: AppColors.gold),
                            ),
                          ),
                        ],
                      ),
                    ),
                      ]),
                    ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ───────────────────────── হোম পেইজ ─────────────────────────
class HomeScreen extends StatefulWidget {
  final String myName;
  final String myPhone;
  final Future<void> Function() onLogout;
  const HomeScreen({
    super.key,
    required this.myName,
    required this.myPhone,
    required this.onLogout,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Member> _members = [];
  bool _loading = true;
  String? _error;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final list = await Api.listMembers();
      // পদবিধারীরা আগে, তারপর নামের ক্রমে
      list.sort((a, b) {
        final ad = a.designation.isNotEmpty ? 0 : 1;
        final bd = b.designation.isNotEmpty ? 0 : 1;
        if (ad != bd) return ad - bd;
        return a.name.compareTo(b.name);
      });
      if (!mounted) return;
      setState(() => _members = list);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _back() {
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    } else {
      SystemNavigator.pop();
    }
  }

  Future<void> _askAdminPassword() async {
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('অ্যাডমিন পাসওয়ার্ড'),
        content: TextField(
          controller: ctrl,
          obscureText: true,
          autofocus: true,
          keyboardType: TextInputType.visiblePassword,
          decoration: const InputDecoration(hintText: 'পাসওয়ার্ড দিন'),
          onSubmitted: (_) => Navigator.pop(ctx, ctrl.text == Config.adminPassword),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('বাতিল')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.red),
            onPressed: () => Navigator.pop(ctx, ctrl.text == Config.adminPassword),
            child: const Text('প্রবেশ'),
          ),
        ],
      ),
    );
    ctrl.dispose();
    if (!mounted) return;
    if (ok == true) {
      await Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => const AdminScreen()));
      _refresh();
    } else if (ok == false) {
      showSnack(context, 'পাসওয়ার্ড সঠিক নয়।');
    }
  }

  Future<void> _confirmLogout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('লগআউট'),
        content: const Text('আপনি কি লগআউট করতে চান?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('হ্যাঁ'),
          ),
        ],
      ),
    );
    if (ok == true) await widget.onLogout();
  }

  @override
  Widget build(BuildContext context) {
    final q = _query.trim().toLowerCase();
    final shown = q.isEmpty
        ? _members
        : _members
            .where((m) =>
                m.name.toLowerCase().contains(q) ||
                m.phone.contains(q) ||
                m.designation.toLowerCase().contains(q))
            .toList();

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.black.withOpacity(0.35),
        elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back), onPressed: _back),
        title: const Text(
          Config.appName,
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
        ),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert),
            color: const Color(0xFF12352A),
            onSelected: (v) {
              if (v == 'wa') openWhatsapp();
              if (v == 'admin') _askAdminPassword();
              if (v == 'logout') _confirmLogout();
            },
            itemBuilder: (_) => [
              PopupMenuItem<String>(
                value: 'wa',
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 250),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.chat, color: Color(0xFF25D366), size: 20),
                          const SizedBox(width: 8),
                          Text(
                            Config.adminWhatsapp,
                            style: const TextStyle(
                                fontWeight: FontWeight.w800, fontSize: 16),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'নতুন সদস্যরা পদের জন্য এখানে যোগাযোগ করুন',
                        style: TextStyle(fontSize: 13, color: Colors.white70),
                      ),
                    ],
                  ),
                ),
              ),
              const PopupMenuDivider(),
              const PopupMenuItem<String>(
                value: 'admin',
                child: Row(children: [
                  Icon(Icons.admin_panel_settings, size: 20),
                  SizedBox(width: 8),
                  Text('অ্যাডমিন'),
                ]),
              ),
              const PopupMenuItem<String>(
                value: 'logout',
                child: Row(children: [
                  Icon(Icons.logout, size: 20),
                  SizedBox(width: 8),
                  Text('লগআউট'),
                ]),
              ),
            ],
          ),
        ],
      ),
      body: AppBackground(
        child: RefreshIndicator(
          color: AppColors.red,
          onRefresh: _refresh,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: EdgeInsets.zero,
            children: [
              // ব্যানার (একদম উপরে)
              Stack(
                children: [
                  SizedBox(
                    width: double.infinity,
                    child: Image.asset(
                      'assets/banner.jpg',
                      fit: BoxFit.fitWidth,
                    ),
                  ),
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    height: 40,
                    child: Container(
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.transparent, AppColors.deepGreen],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
                child: TextField(
                  onChanged: (v) => setState(() => _query = v),
                  decoration: InputDecoration(
                    hintText: 'নাম, নাম্বার বা পদবি দিয়ে খুঁজুন',
                    prefixIcon: const Icon(Icons.search, color: Colors.white70),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.08),
                    contentPadding: const EdgeInsets.symmetric(vertical: 0),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 10, 20, 6),
                child: Row(
                  children: [
                    Container(width: 4, height: 18, color: AppColors.red),
                    const SizedBox(width: 8),
                    Text(
                      'সদস্য তালিকা (${_members.length} জন)',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
              if (_loading)
                const Padding(
                  padding: EdgeInsets.all(40),
                  child: Center(child: CircularProgressIndicator(color: AppColors.red)),
                )
              else if (_error != null)
                Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      Text(_error!,
                          textAlign: TextAlign.center,
                          style: const TextStyle(color: Color(0xFFFF8A95))),
                      const SizedBox(height: 12),
                      FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: AppColors.red),
                        onPressed: _refresh,
                        child: const Text('আবার চেষ্টা করুন'),
                      ),
                    ],
                  ),
                )
              else if (shown.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(40),
                  child: Center(child: Text('কোনো সদস্য পাওয়া যায়নি।')),
                )
              else
                ...shown.map((m) => MemberTile(
                      member: m,
                      isMe: m.phone == widget.myPhone,
                    )),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}

class MemberTile extends StatelessWidget {
  final Member member;
  final bool isMe;
  const MemberTile({super.key, required this.member, this.isMe = false});

  @override
  Widget build(BuildContext context) {
    final hasPost = member.designation.isNotEmpty;
    final initial =
        member.name.isNotEmpty ? String.fromCharCode(member.name.runes.first) : '?';
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Container(
          color: Colors.black.withOpacity(0.28),
          child: Row(
            children: [
              Container(
                width: 4,
                height: 72,
                color: hasPost ? AppColors.red : AppColors.green,
              ),
              Expanded(
                child: ListTile(
        onTap: () => launchUrl(Uri.parse('tel:${member.phone}')),
        leading: CircleAvatar(
          backgroundColor: hasPost ? AppColors.red : AppColors.green,
          child: Text(initial,
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        ),
        title: Text(
          isMe ? '${member.name} (আমি)' : member.name,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(member.phone, style: const TextStyle(color: Colors.white70)),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: hasPost
                ? AppColors.red.withOpacity(0.25)
                : AppColors.green.withOpacity(0.35),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            hasPost ? member.designation : 'সদস্য',
            style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w700,
              color: hasPost ? AppColors.gold : Colors.white,
            ),
          ),
        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ───────────────────────── অ্যাডমিন প্যানেল ─────────────────────────
class AdminScreen extends StatefulWidget {
  const AdminScreen({super.key});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  static const presets = [
    'সভাপতি',
    'সহ-সভাপতি',
    'সাধারণ সম্পাদক',
    'যুগ্ম সাধারণ সম্পাদক',
    'সাংগঠনিক সম্পাদক',
    'সদস্য',
  ];

  List<Member> _members = [];
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final list = await Api.listMembers();
      list.sort((a, b) => a.name.compareTo(b.name));
      if (!mounted) return;
      setState(() => _members = list);
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = 'ইন্টারনেট সংযোগ পরীক্ষা করে আবার চেষ্টা করুন।');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _editDesignation(Member m) async {
    final ctrl = TextEditingController(text: m.designation);
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: Text('${m.name} এর পদবি'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: ctrl,
                  autofocus: true,
                  decoration: const InputDecoration(hintText: 'পদবি লিখুন'),
                ),
                const SizedBox(height: 14),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: presets
                      .map((p) => ActionChip(
                            label: Text(p, style: const TextStyle(fontSize: 12)),
                            onPressed: () => setD(() => ctrl.text = p),
                          ))
                      .toList(),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('বাতিল')),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppColors.red),
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: const Text('সংরক্ষণ'),
            ),
          ],
        ),
      ),
    );
    ctrl.dispose();
    if (result == null) return;
    try {
      await Api.setDesignation(m.phone, result);
      if (!mounted) return;
      showSnack(context, 'পদবি সংরক্ষণ হয়েছে।');
      _load();
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message);
    } catch (_) {
      if (mounted) showSnack(context, 'ইন্টারনেট সংযোগ পরীক্ষা করুন।');
    }
  }

  Future<void> _delete(Member m) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('সদস্য মুছে ফেলবেন?'),
        content: Text('${m.name} (${m.phone}) কে তালিকা থেকে মুছে ফেলা হবে।'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('না')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('মুছুন'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Api.deleteMember(m.phone);
      if (!mounted) return;
      showSnack(context, 'মুছে ফেলা হয়েছে।');
      _load();
    } on ApiException catch (e) {
      if (mounted) showSnack(context, e.message);
    } catch (_) {
      if (mounted) showSnack(context, 'ইন্টারনেট সংযোগ পরীক্ষা করুন।');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.deepRed,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('অ্যাডমিন প্যানেল'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
        ],
      ),
      body: AppBackground(
        child: _loading
            ? const Center(child: CircularProgressIndicator(color: AppColors.red))
            : _error != null
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(_error!, textAlign: TextAlign.center),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    itemCount: _members.length,
                    itemBuilder: (_, i) {
                      final m = _members[i];
                      return Container(
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.28),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: ListTile(
                          title: Text(m.name,
                              style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(
                            '${m.phone}\nপদবি: ${m.designation.isEmpty ? 'নেই' : m.designation}',
                            style: const TextStyle(color: Colors.white70, height: 1.4),
                          ),
                          isThreeLine: true,
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                tooltip: 'পদবি দিন',
                                icon: const Icon(Icons.edit, color: AppColors.gold),
                                onPressed: () => _editDesignation(m),
                              ),
                              IconButton(
                                tooltip: 'মুছুন',
                                icon: const Icon(Icons.delete_outline,
                                    color: Color(0xFFFF8A95)),
                                onPressed: () => _delete(m),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}
